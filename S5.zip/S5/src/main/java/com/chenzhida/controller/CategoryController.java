package com.chenzhida.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chenzhida.model.CategoryExample;
import com.chenzhida.service.ICategoryService;

@Controller
@RequestMapping(value={"/category"})
public class CategoryController {
	@Autowired
	private ICategoryService service=null;
	
	@RequestMapping(value={"/cshow"})
	public void cshow(HttpServletResponse response){
		CategoryExample example=new CategoryExample();
		example.createCriteria().andCatidIsNotNull();		
		String json=service.selectByExample(example);
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		PrintWriter out=null;
		try {
			out=response.getWriter();
			out.write(json);
			System.out.println(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		out.flush();
		out.close();
		
		
	}
	
}
