package com.chenzhida.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chenzhida.service.IPetService;

@Controller
@RequestMapping(value={"/pet"})
public class PetController {
	@Autowired
	private IPetService service;
	@RequestMapping(value={"/showP/cate/{cate}"})
	public String showP(@PathVariable(value="cate") String cate,
			Map map1){
		Map map=new HashMap(); 
		map.put("in_cate", cate);
		map.put("in_pro", "");
		map.put("in_item", "");
		
		map1.put("plist", service.showP(map));		
		
		return "shop/pro.ftl";
	}
	
	@RequestMapping(value={"/showI/pid/{pid}"})
	public String showI(@PathVariable(value="pid") String pid,
			Map map1){
		Map map=new HashMap(); 
		map.put("in_cate", "");
		map.put("in_pro", pid);
		map.put("in_item", "");
		
		map1.put("plist", service.showI(map));		
		
		return "shop/items.ftl";
	}
	
	@RequestMapping(value={"/showItem/item/{item}"})
	public String showItem(@PathVariable(value="item") String item,
			Map map1){
		Map map=new HashMap(); 
		map.put("in_cate", "");
		map.put("in_pro", "");
		map.put("in_item", item);
		
		map1.put("plist", service.showI(map));		
		
		return "shop/item.ftl";
	}
}
