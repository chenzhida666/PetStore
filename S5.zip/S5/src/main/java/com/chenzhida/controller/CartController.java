package com.chenzhida.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.chenzhida.service.ICartService;

@Controller
@RequestMapping(value={"/cart"})
public class CartController {

	@Autowired
	private ICartService service;
	
	@RequestMapping(value={"/showC/item/{itemid}/qty/{qty}"})
	public String showC(@PathVariable(value="itemid") String itemid,
			@PathVariable(value="qty") String qty,Map map1){
		HashMap map=new HashMap();
		
		map.put("in_itemid", itemid);
		map.put("in_qty", qty);
		
		map1.put("clist", service.addCart(map));
		return "shop/add.ftl";
	}
	
	@RequestMapping(value={"/delC/item/{itemid}/orderid/{orderid}"})
	public String delC(@PathVariable(value="itemid") String itemid,
			@PathVariable(value="orderid") String orderid,Map map1){
		HashMap map=new HashMap();
		
		map.put("in_orderid", orderid);
		map.put("in_itemid", itemid);
		map1.put("clist", service.delCart(map));
		
		return "shop/add.ftl";
	}
	
	@RequestMapping(value={"/updateC"})
	public String updateC(@RequestParam List<String> ilist,
			@RequestParam List<String> qlist,
         Map map1){
		Map map=new HashMap();
		for(int i=0;i<ilist.size();i++){
			map.put("in_itemid",ilist.get(i) );
			map.put("in_qty",qlist.get(i) );
			service.updateCart(map);
		}
		
		map1.put("clist", service.queryCart());
		
		return "shop/add.ftl";
	}
	
	@RequestMapping(value={"/orders/orderid/{orderid}"})
	public String updateOrders(@PathVariable(value="orderid") String orderid){
		Map map=new HashMap();
		
		map.put("in_orderid", orderid);
		service.updateOrders(map);
		return "shop/main.ftl";
	}
}
