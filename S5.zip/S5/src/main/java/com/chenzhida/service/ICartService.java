package com.chenzhida.service;

import java.util.List;
import java.util.Map;

import com.chenzhida.model.Cart;

public interface ICartService {

	List<Cart> queryCart();
    List<Cart> addCart (Map map);
    List<Cart> delCart (Map map);
    void updateCart (Map map);
    void updateOrders (Map map);
}
