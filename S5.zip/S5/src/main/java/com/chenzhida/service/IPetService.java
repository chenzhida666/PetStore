package com.chenzhida.service;

import java.util.List;
import java.util.Map;

public interface IPetService {

	List showP(Map map);
	List showI(Map map);
}
