package com.chenzhida.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chenzhida.dao.CartMapper;
import com.chenzhida.model.Cart;
@Service
public class CartServiceImpl implements ICartService {
	@Autowired
	private CartMapper dao;

	@Override
	public List<Cart> queryCart() {
		// TODO Auto-generated method stub
		return dao.queryCart();
	}

	@Override
	public List<Cart> addCart(Map map) {
		// TODO Auto-generated method stub
		return dao.addCart(map);
	}

	@Override
	public List<Cart> delCart(Map map) {
		// TODO Auto-generated method stub
		return dao.delCart(map);
	}

	@Override
	public void updateCart(Map map) {
		// TODO Auto-generated method stub
		dao.updateCart(map);
	}

	@Override
	public void updateOrders(Map map) {
		// TODO Auto-generated method stub
		dao.updateOrders(map);
	}

	
}
