package com.chenzhida.service;

import com.chenzhida.model.CategoryExample;

public interface ICategoryService {
	
    String selectByExample(CategoryExample example);

}
