package com.chenzhida.model;

import java.util.List;

public class Cart extends CartKey {
    private Integer quantity;

    private List<Item> list;
    private Item item;
    
    
    public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<Item> getList() {
		return list;
	}

	public void setList(List<Item> list) {
		this.list = list;
	}

	public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}