package com.chenzhida.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value={"/index"})
public class IndexController {
	@RequestMapping(value={"/index"})
	
	public String index(){
		return "index.ftl";
	}	
	
	@RequestMapping(value={"/main"})
	
	public String main(){
		return "shop/main.ftl";
	}	
	
	
}
