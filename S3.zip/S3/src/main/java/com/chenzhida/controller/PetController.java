package com.chenzhida.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chenzhida.service.IPetService;

@Controller
@RequestMapping(value={"/pet"})
public class PetController {
	@Autowired 
	private IPetService service;
	@RequestMapping(value={"/showp/cate/{cate}"})
	public String showP(@PathVariable String cate,Map map1){
		
		Map map=new HashMap();
		map.put("in_cate", cate);
		map.put("in_pro", "");
		map.put("in_item", "");
		map1.put("plist", service.showP(map));
				
		return "shop/pro.ftl";
	}
	
	@RequestMapping(value={"/showis/pro/{pro}"})
	public String showItems(@PathVariable String pro,Map map1){
	
		Map map=new HashMap();
		map.put("in_cate", "");
		map.put("in_pro", pro);
		map.put("in_item", "");
		map1.put("plist", service.showItems(map));
		
		return "shop/items.ftl";
	}	
	@RequestMapping(value={"/showi/item/{item}"})
	public String showItem(@PathVariable String item,Map map1){
		
		Map map=new HashMap();
		map.put("in_cate", "");
		map.put("in_pro", "");
		map.put("in_item", item);
		map1.put("plist", service.showItems(map));
		
		
		return "shop/item.ftl";
		
	}
}
