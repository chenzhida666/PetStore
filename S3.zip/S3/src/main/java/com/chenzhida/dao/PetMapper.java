package com.chenzhida.dao;

import java.util.List;
import java.util.Map;

public interface PetMapper {

	List showP(Map map);
	List showItems(Map map);
	List showItem(Map map);

}
