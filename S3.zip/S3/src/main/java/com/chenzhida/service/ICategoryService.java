package com.chenzhida.service;

import java.util.List;


import com.chenzhida.model.Category;
import com.chenzhida.model.CategoryExample;

public interface ICategoryService {
	String selectByExample(CategoryExample example);
}
