package com.chenzhida.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.chenzhida.dao.CategoryMapper;
import com.chenzhida.model.Cart;
import com.chenzhida.model.CartExample;
import com.chenzhida.model.Category;
import com.chenzhida.model.CategoryExample;
@Service
public class CategoryServiceImpl implements ICategoryService {
	@Autowired
	private CategoryMapper dao; 
	@Override
	public String selectByExample(CategoryExample example) {
		// TODO Auto-generated method stub
		
		List<Category> list=dao.selectByExample(example);
				
		
		return JSONArray.toJSONString(list);
	}



}
