package com.chenzhida.service;

import java.util.List;

import com.chenzhida.model.Account;
import com.chenzhida.model.AccountExample;


public interface IAccountService {
	List<Account> selectByExample(AccountExample example);
	int insert(Account record);
}
